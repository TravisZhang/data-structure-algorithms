head.next.next = Node(4)
head.next.next.next = Node(3)
head.next.next.next.next = Node(5)