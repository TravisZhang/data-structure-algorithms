class Queue:
    
    def __init__(self):
        self.head = None
        self.tail = None
        self.num_elements = 0