# The time complexity of the above implementation
# is dominated by the two nested loops,
# which give us an O(N^2) time complexity.